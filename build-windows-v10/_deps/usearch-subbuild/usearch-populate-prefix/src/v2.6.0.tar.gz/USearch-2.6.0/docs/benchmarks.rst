========================
Benchmarks
========================

.. mdinclude:: benchmarks.md